---
title: 关于
icon: fas fa-info
order: 4
---
- ### Hi there 👋, I'm Tom!

  - 🏫  _BSc in Computer Science_.
  - 💻  I work on C / C++ / Java / Objective-C & Swift / Python / Markdown.
  - 🧠  I used to take internship as an iOS developer at Bytedance Techonology.
  - 🏖️  I will go to Shenzhen and work as a back-end engineer at Tencent.

公众号: 汤姆还在写代码

