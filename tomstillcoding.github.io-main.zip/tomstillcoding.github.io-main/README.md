# B站ID：湾区书记汤姆
该博客是通过 GitHub Pages + Jekyll(主题是Chirpy) 搭建而成的
下面是关于 Chirpy 的搭建示例~


# Chirpy

Chirpy 主题的 GitHub 链接是：[**Chirpy**][chirpy] 

[chirpy]: https://github.com/cotes2020/jekyll-theme-chirpy/
